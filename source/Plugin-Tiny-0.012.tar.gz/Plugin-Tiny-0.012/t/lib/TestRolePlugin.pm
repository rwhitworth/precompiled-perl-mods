package TestRolePlugin;
use Moo::Role;
use strict;
use warnings;
requires 'some_method';

1;