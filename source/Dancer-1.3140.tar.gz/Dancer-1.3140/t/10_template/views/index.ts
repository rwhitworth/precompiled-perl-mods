bar => <% bar %>
