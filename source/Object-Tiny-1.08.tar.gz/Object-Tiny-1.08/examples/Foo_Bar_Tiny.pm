package Foo_Bar_Tiny;

use Object::Tiny qw{ foo bar baz };

1;
