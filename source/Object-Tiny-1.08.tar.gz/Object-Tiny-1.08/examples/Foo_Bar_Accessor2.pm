package Foo_Bar_Accessor2;

use base 'Class::Accessor::Fast';
Foo_Bar_Accessor->mk_ro_accessors(qw{ q w e r t y u i o p a s d f g h j k l z x c v b n m });

1;
